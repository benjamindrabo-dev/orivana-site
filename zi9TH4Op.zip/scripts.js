/* Orivana shared scripts — language switch + AI demo */

function getLang() {
  return document.documentElement.getAttribute('data-lang') || 'fr';
}

function setLang(lang) {
  document.documentElement.setAttribute('data-lang', lang);
  document.querySelectorAll('[data-fr]').forEach(function(el){
    var val = el.getAttribute('data-' + lang);
    if (val !== null) {
      if (el.children.length === 0) el.textContent = val;
      else el.innerHTML = val;
    }
  });
  document.querySelectorAll('[data-fr-ph]').forEach(function(el){
    var val = el.getAttribute('data-' + lang + '-ph');
    if (val) el.setAttribute('placeholder', val);
  });
  document.querySelectorAll('.lang-switch button').forEach(function(btn){
    btn.classList.toggle('active', btn.dataset.lang === lang);
  });
}

function initLang() {
  setLang('fr');
  document.querySelectorAll('.lang-switch button').forEach(function(btn){
    btn.addEventListener('click', function(){ setLang(btn.dataset.lang); });
  });
}

function initNav() {
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (!toggle || !links) return;
  toggle.addEventListener('click', function(){ links.classList.toggle('open'); });
}

/* ---------- Fallback demo scripts ---------- */

var DEMO_SCRIPT_FR = [
  { text: "🔎 Connexion à l'API Claude...", delay: 500 },
  { text: "✓ Authentification réussie", delay: 400, cls: 'good' },
  { text: "", delay: 200 },
  { text: "📍 Analyse de {business} ({city}, QC)", delay: 600, ai: true },
  { text: "⏳ Recherche web des 3 concurrents top du map pack canadien...", delay: 1000 },
  { text: "", delay: 200 },
  { text: "▼ CONCURRENTS DÉTECTÉS", delay: 400, ai: true },
  { text: "  1. {competitor1} — 4,8★ (247 avis) — 142 photos", delay: 400 },
  { text: "  2. {competitor2} — 4,6★ (183 avis) — 89 photos", delay: 400 },
  { text: "  3. {competitor3} — 4,7★ (156 avis) — 67 photos", delay: 400 },
  { text: "", delay: 200 },
  { text: "▼ AUDIT DE VOTRE FICHE GOOGLE", delay: 400, ai: true },
  { text: "  Photos             : 8  (vs moy. 99)", delay: 300, cls: 'bad' },
  { text: "  Catégories         : 2  (vs moy. 6)", delay: 300, cls: 'bad' },
  { text: "  Avis Google        : 31 (vs moy. 195)", delay: 300, cls: 'bad' },
  { text: "  Publications / mois: 0  (vs moy. 8)", delay: 300, cls: 'bad' },
  { text: "  Q&R actives        : 1  (vs moy. 12)", delay: 300, cls: 'bad' },
  { text: "", delay: 200 },
  { text: "▼ SCORE SEO LOCAL", delay: 400, ai: true },
  { text: "  ████░░░░░░  34 / 100", delay: 500, cls: 'score' },
  { text: "", delay: 200 },
  { text: "▼ 5 ACTIONS PRIORITAIRES (semaine 1)", delay: 400, ai: true },
  { text: "  ① Ajouter catégorie secondaire « Urgence {service} »", delay: 350, cls: 'good' },
  { text: "  ② Publier 30 photos avant/après", delay: 350, cls: 'good' },
  { text: "  ③ Activer les publications GBP — 30 prêtes", delay: 350, cls: 'good' },
  { text: "  ④ Seeder 15 Q&R avec mots-clés locaux", delay: 350, cls: 'good' },
  { text: "  ⑤ Répondre à tous les avis existants", delay: 350, cls: 'good' },
  { text: "", delay: 200 },
  { text: "📈 Potentiel estimé : +340% de leads sur 90 jours", delay: 600, ai: true, cls: 'score' },
  { text: "🔒 Exclusivité vérifiée : 1 seul {service} accepté à {city}", delay: 400, ai: true, cls: 'good' },
  { text: "", delay: 100 },
  { text: "➜ Ceci est un aperçu. Le rapport complet d'Orivana fait 40 pages.", delay: 400, cls: 'good' }
];

var DEMO_SCRIPT_EN = [
  { text: "🔎 Connecting to Claude API...", delay: 500 },
  { text: "✓ Authentication successful", delay: 400, cls: 'good' },
  { text: "", delay: 200 },
  { text: "📍 Analyzing {business} ({city}, QC)", delay: 600, ai: true },
  { text: "⏳ Web-searching top 3 Canadian map-pack competitors...", delay: 1000 },
  { text: "", delay: 200 },
  { text: "▼ COMPETITORS DETECTED", delay: 400, ai: true },
  { text: "  1. {competitor1} — 4.8★ (247 reviews) — 142 photos", delay: 400 },
  { text: "  2. {competitor2} — 4.6★ (183 reviews) — 89 photos", delay: 400 },
  { text: "  3. {competitor3} — 4.7★ (156 reviews) — 67 photos", delay: 400 },
  { text: "", delay: 200 },
  { text: "▼ YOUR GOOGLE PROFILE AUDIT", delay: 400, ai: true },
  { text: "  Photos            : 8   (vs avg 99)", delay: 300, cls: 'bad' },
  { text: "  Categories        : 2   (vs avg 6)", delay: 300, cls: 'bad' },
  { text: "  Google reviews    : 31  (vs avg 195)", delay: 300, cls: 'bad' },
  { text: "  Posts / month     : 0   (vs avg 8)", delay: 300, cls: 'bad' },
  { text: "  Active Q&A        : 1   (vs avg 12)", delay: 300, cls: 'bad' },
  { text: "", delay: 200 },
  { text: "▼ LOCAL SEO SCORE", delay: 400, ai: true },
  { text: "  ████░░░░░░  34 / 100", delay: 500, cls: 'score' },
  { text: "", delay: 200 },
  { text: "▼ TOP 5 ACTIONS (week 1)", delay: 400, ai: true },
  { text: "  ① Add secondary category « Emergency {service} »", delay: 350, cls: 'good' },
  { text: "  ② Upload 30 before/after photos", delay: 350, cls: 'good' },
  { text: "  ③ Enable GBP posts — 30 ready", delay: 350, cls: 'good' },
  { text: "  ④ Seed 15 Q&As with local keywords", delay: 350, cls: 'good' },
  { text: "  ⑤ Reply to all existing reviews", delay: 350, cls: 'good' },
  { text: "", delay: 200 },
  { text: "📈 Estimated upside: +340% leads in 90 days", delay: 600, ai: true, cls: 'score' },
  { text: "🔒 Exclusivity verified: only 1 {service} accepted in {city}", delay: 400, ai: true, cls: 'good' },
  { text: "", delay: 100 },
  { text: "➜ This is a preview. Orivana's full report is 40 pages.", delay: 400, cls: 'good' }
];

var COMPETITORS_POOL = {
  fr: [
    ["Services Lavoie inc.", "Experts Bélanger", "Maison Gagnon"],
    ["Artisans Dubois", "Service Rapide QC", "Équipe Pro Laval"],
    ["Atelier Latendresse", "Experts Desjardins", "Rénov Québec Express"]
  ],
  en: [
    ["Lavoie Services Inc.", "Belanger Experts", "Gagnon Home Co"],
    ["Dubois Craftsmen", "QuickService QC", "TeamPro Laval"],
    ["Latendresse Workshop", "Desjardins Home Experts", "Quebec FastRenov"]
  ]
};

/* ---------- Output renderer ---------- */

function classifyLine(text) {
  if (!text) return { cls: '', ai: false };
  var t = text.trim();
  if (/^▼/.test(t) || /^📍/.test(t)) return { cls: '', ai: true };
  if (/^📈/.test(t) || /^🔒/.test(t)) return { cls: 'good', ai: true };
  if (/^✓/.test(t) || /^➜/.test(t) || /^[①②③④⑤]/.test(t)) return { cls: 'good', ai: false };
  if (/\d+\s*\/\s*100/.test(t) || /[█░]{3,}/.test(t)) return { cls: 'score', ai: false };
  if (/^(Photos|Catégories|Categories|Avis|Reviews|Publications|Posts|Q&R|Q&A|Note|Rating)/i.test(t)) return { cls: 'bad', ai: false };
  return { cls: '', ai: false };
}

function escapeHtml(s) {
  return String(s).replace(/[&<>]/g, function(c){ return { '&':'&amp;','<':'&lt;','>':'&gt;' }[c]; });
}

function appendLine(output, rawText) {
  var text = rawText == null ? '' : String(rawText);
  var meta = classifyLine(text);
  var div = document.createElement('div');
  div.className = 'line' + (meta.cls ? ' ' + meta.cls : '');
  if (meta.ai && text) div.innerHTML = '<span class="ai-label">[AI]</span> ' + escapeHtml(text);
  else div.textContent = text || '\u00A0';
  output.appendChild(div);
  output.scrollTop = output.scrollHeight;
}

/* ---------- Real audit via /api/audit (SSE) ---------- */

function runRealAudit(params, output, callbacks) {
  var onFirst = callbacks.onFirst || function(){};
  var onDone = callbacks.onDone || function(){};
  var onFail = callbacks.onFail || function(){};

  var controller = new AbortController();
  var buffer = '';
  var textBuffer = '';
  var gotAnything = false;

  fetch('/api/audit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
    signal: controller.signal
  }).then(function(resp){
    if (!resp.ok || !resp.body) {
      throw new Error('API unavailable (' + resp.status + ')');
    }
    var reader = resp.body.getReader();
    var decoder = new TextDecoder();

    function flushLines() {
      var nl = textBuffer.indexOf('\n');
      while (nl !== -1) {
        var line = textBuffer.slice(0, nl);
        textBuffer = textBuffer.slice(nl + 1);
        appendLine(output, line);
        nl = textBuffer.indexOf('\n');
      }
    }

    function pump() {
      return reader.read().then(function(res){
        if (res.done) {
          if (textBuffer.length) { appendLine(output, textBuffer); textBuffer = ''; }
          onDone();
          return;
        }
        buffer += decoder.decode(res.value, { stream: true });
        var parts = buffer.split(/\n\n/);
        buffer = parts.pop();
        parts.forEach(function(chunk){
          var event = 'message', data = '';
          chunk.split('\n').forEach(function(l){
            if (l.indexOf('event:') === 0) event = l.slice(6).trim();
            else if (l.indexOf('data:') === 0) data += l.slice(5).trim();
          });
          if (!data) return;
          var parsed;
          try { parsed = JSON.parse(data); } catch (e) { return; }
          if (event === 'text' && parsed.delta) {
            if (!gotAnything) { gotAnything = true; onFirst(); }
            textBuffer += parsed.delta;
            flushLines();
          } else if (event === 'error') {
            appendLine(output, '⚠ ' + (parsed.message || 'error'));
          } else if (event === 'done') {
            if (textBuffer.length) { appendLine(output, textBuffer); textBuffer = ''; }
          }
        });
        return pump();
      });
    }

    return pump();
  }).catch(function(err){
    if (gotAnything) onDone();
    else onFail(err);
  });

  return controller;
}

/* ---------- Simulated fallback ---------- */

function runSimulatedAudit(params, output, onDone) {
  var lang = params.lang;
  var script = lang === 'en' ? DEMO_SCRIPT_EN : DEMO_SCRIPT_FR;
  var compPool = COMPETITORS_POOL[lang];
  var competitors = compPool[Math.floor(Math.random() * compPool.length)];

  var i = 0;
  function next() {
    if (i >= script.length) { onDone && onDone(); return; }
    var item = script[i++];
    var text = item.text
      .split('{business}').join(params.business)
      .split('{city}').join(params.city)
      .split('{service}').join(params.service)
      .split('{competitor1}').join(competitors[0])
      .split('{competitor2}').join(competitors[1])
      .split('{competitor3}').join(competitors[2]);

    var div = document.createElement('div');
    div.className = 'line' + (item.cls ? ' ' + item.cls : '');
    if (item.ai) div.innerHTML = '<span class="ai-label">[AI]</span> ' + escapeHtml(text);
    else div.textContent = text || '\u00A0';
    output.appendChild(div);
    output.scrollTop = output.scrollHeight;
    setTimeout(next, item.delay);
  }
  next();
}

/* ---------- Orchestrator ---------- */

function runDemo() {
  var business = document.getElementById('demo-business').value.trim() || 'Votre Entreprise';
  var city = document.getElementById('demo-city').value.trim() || 'Montréal';
  var service = document.getElementById('demo-service').value.trim() || 'plomberie';
  var output = document.getElementById('demo-output');
  var btn = document.getElementById('demo-run');
  if (!output || !btn) return;

  var lang = getLang();
  var params = { business: business, city: city, service: service, lang: lang };

  output.classList.add('show');
  output.innerHTML = '';
  btn.disabled = true;
  btn.innerHTML = lang === 'en' ? '⏳ Running AI audit...' : '⏳ Audit IA en cours...';

  function finish() {
    btn.disabled = false;
    btn.innerHTML = lang === 'en' ? '⚡ Run another audit' : '⚡ Refaire un audit';
  }

  appendLine(output, lang === 'en' ? '🔎 Connecting to Claude API...' : "🔎 Connexion à l'API Claude...");

  runRealAudit(params, output, {
    onFirst: function(){},
    onDone: finish,
    onFail: function(){
      output.innerHTML = '';
      var note = document.createElement('div');
      note.className = 'line';
      note.style.color = '#f59e0b';
      note.textContent = lang === 'en'
        ? '⚠ Backend not configured — showing simulated preview. See DEPLOY.md to enable the real Claude audit.'
        : '⚠ Backend non configuré — aperçu simulé. Voir DEPLOY.md pour activer le vrai audit Claude.';
      output.appendChild(note);
      runSimulatedAudit(params, output, finish);
    }
  });
}

function initDemo() {
  var btn = document.getElementById('demo-run');
  if (btn) btn.addEventListener('click', runDemo);
}

function initContact() {
  var form = document.getElementById('contact-form');
  if (!form) return;
  form.addEventListener('submit', function(e){
    e.preventDefault();
    var lang = getLang();
    var msg = lang === 'en'
      ? 'Thanks! We will reach out within 24h.'
      : 'Merci ! Nous vous recontactons sous 24h.';
    var box = document.getElementById('contact-success');
    if (box) { box.style.display = 'block'; box.textContent = msg; }
    form.reset();
  });
}

document.addEventListener('DOMContentLoaded', function(){
  initLang();
  initNav();
  initDemo();
  initContact();
});
